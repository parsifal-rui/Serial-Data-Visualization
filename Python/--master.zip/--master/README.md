# -
python串口示波器上位机

![软件面板](/view.png)

make in 2020-5-17
python---------3.6.8
PyQt-----------5.10
pyqtgraph------0.10.0
serial---------0.0.97
serial-tool----0.0.1
numpy----------1.18.4
pyinstaller----3.4
